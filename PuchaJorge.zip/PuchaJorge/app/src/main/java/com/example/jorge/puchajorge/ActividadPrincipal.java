package com.example.jorge.puchajorge;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class ActividadPrincipal extends AppCompatActivity {
    EditText cajaHam,cajaCer, cajaEns,cajaSal;
    Button botonGuardar;
    TextView hamburguesa,cerveza,ensalada,salchipapa,total,iva,detalle;
    String texto,val1,val2,val3,val4,detallecad;
    String cad[],valor[];
    Double valH,valC,valE,valS,suma,valIva;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_principal);

        cajaHam = (EditText) findViewById(R.id.txtCantHam);
        cajaCer = (EditText) findViewById(R.id.txtCantCer);
        cajaEns = (EditText) findViewById(R.id.txtCantEns);
        cajaSal = (EditText) findViewById(R.id.txtCantSal);
        botonGuardar =(Button) findViewById(R.id.btnGuardarDB);
        hamburguesa = (TextView) findViewById(R.id.lblHambuerguesa);
        cerveza = (TextView) findViewById(R.id.lblCerveza);
        ensalada = (TextView) findViewById(R.id.lblEnsalada);
        salchipapa = (TextView) findViewById(R.id.lblSalchipapa);
        total= (TextView) findViewById(R.id.lblTotal);
        iva= (TextView) findViewById(R.id.lblIva);
        detalle= (TextView) findViewById(R.id.lblDetalle);

        InputStream input=getResources().openRawResource(R.raw.raw_archivo);
        BufferedReader lector=new BufferedReader(new InputStreamReader(input));
        try {
            texto=lector.readLine();
            cad=texto.split(";");
            hamburguesa.setText(cad[0]);
            cerveza.setText(cad[1]);
            ensalada.setText(cad[2]);
            salchipapa.setText(cad[3]);


            lector.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        botonGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val1=cad[0];
                valor=val1.split(",");
                valH=Double.parseDouble(valor[1]);
                valor=null;
                val2=cad[1];
                valor=val2.split(",");
                valC=Double.parseDouble(valor[1]);
                valor=null;
                val3=cad[2];
                valor=val3.split(",");
                valE=Double.parseDouble(valor[1]);
                valor=null;
                val4=cad[3];
                valor=val4.split(",");
                valS=Double.parseDouble(valor[1]);

                suma=(valH*Double.parseDouble(cajaHam.getText().toString()))+(valC*Double.parseDouble(cajaCer.getText().toString()))+(valE*Double.parseDouble(cajaEns.getText().toString()))+(valS*Double.parseDouble(cajaSal.getText().toString()));
                if(suma<=10){
                    total.setText("Total: "+String.valueOf(suma));
                    detallecad="";
                    detallecad+='\n'+"Cantidad de Hamburquesas: "+cajaHam.getText().toString();
                    detallecad+='\n'+"Cantidad de Cervezas: "+cajaCer.getText().toString();
                    detallecad+='\n'+"Cantidad de Ensaladas: "+cajaEns.getText().toString();
                    detallecad+='\n'+"Cantidad de Salchipapas: "+cajaSal.getText().toString();
                    detalle.setText(detallecad);
                }
                else{
                    detallecad="";
                    suma=suma+(suma*0.12);
                    total.setText("Total: "+String.valueOf(suma));
                    valIva=suma*0.12;
                    iva.setText("Iva: "+String.valueOf(valIva));
                    detallecad+='\n'+"Cantidad de Hamburquesas: "+cajaHam.getText().toString();
                    detallecad+='\n'+"Cantidad de Cervezas: "+cajaCer.getText().toString();
                    detallecad+='\n'+"Cantidad de Ensaladas: "+cajaEns.getText().toString();
                    detallecad+='\n'+"Cantidad de Salchipapas: "+cajaSal.getText().toString();
                    detalle.setText(detallecad);
                }
            }
        });


    }

}
